import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./styles.css";
import { supabase } from "./lib/supabase";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode><App /></React.StrictMode>
);

if ("serviceWorker" in navigator && import.meta.env.PROD) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(console.error));
}
