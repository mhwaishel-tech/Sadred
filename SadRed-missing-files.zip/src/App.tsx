import { useEffect, useMemo, useState } from "react";
import { supabase, isConfigured } from "./lib/supabase";
import type { Listing, Message, Profile, Conversation } from "./types";
import { Search, Plus, Recycle, UserRound, LogOut, MapPin, Euro, MessageCircle, Camera, X, Send, ShieldCheck, Menu, Leaf, PackageOpen } from "lucide-react";

const categories = ["Alles", "Meubels", "Huishoudtoestellen", "Tuin", "Bouwafval", "Overig"];
const money = (n: number) => new Intl.NumberFormat("nl-BE", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(n);

export default function App() {
  const [session, setSession] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [listings, setListings] = useState<Listing[]>([]);
  const [tab, setTab] = useState<"home"|"publish"|"messages"|"account"|"admin">("home");
  const [category, setCategory] = useState("Alles");
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login"|"signup">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [detail, setDetail] = useState<Listing | null>(null);
  const [myConversations, setMyConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageText, setMessageText] = useState("");

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);
  useEffect(() => {
    if (!isConfigured) return;
    loadListings();
  }, [category, query]);
  useEffect(() => {
    if (!session) { setProfile(null); return; }
    loadProfile();
    loadConversations();
  }, [session]);
  useEffect(() => {
    if (!activeConversation) { setMessages([]); return; }
    loadMessages(activeConversation.id);
    const channel = supabase.channel("messages-" + activeConversation.id)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `conversation_id=eq.${activeConversation.id}` },
        payload => setMessages(old => old.some(m => m.id === (payload.new as Message).id) ? old : [...old, payload.new as Message]))
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [activeConversation]);

  async function loadProfile() {
    const { data } = await supabase.from("profiles").select("*").eq("id", session.user.id).maybeSingle();
    setProfile(data as Profile | null);
  }
  async function loadListings() {
    let req = supabase.from("listings").select("*, profiles(display_name)").eq("status", "active").order("created_at", { ascending: false }).limit(60);
    if (category !== "Alles") req = req.eq("category", category);
    if (query.trim()) req = req.or(`title.ilike.%${query.trim()}%,description.ilike.%${query.trim()}%,city.ilike.%${query.trim()}%`);
    const { data, error } = await req;
    if (!error && data) setListings(data as Listing[]);
  }
  async function loadConversations() {
    const { data } = await supabase.from("conversations").select("*, listings(*)").order("created_at", { ascending: false });
    setMyConversations((data || []) as Conversation[]);
  }
  async function loadMessages(id: string) {
    const { data } = await supabase.from("messages").select("*").eq("conversation_id", id).order("created_at");
    setMessages((data || []) as Message[]);
  }
  async function signIn(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setNotice("");
    const result = authMode === "signup"
      ? await supabase.auth.signUp({ email, password, options: { data: { display_name: displayName } } })
      : await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (result.error) setNotice(result.error.message);
    else { setNotice(authMode === "signup" ? "Controleer je e-mail om je account te bevestigen." : "Welkom terug!"); if (authMode === "login") setAuthOpen(false); }
  }
  async function publish(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!session) { setAuthOpen(true); return; }
    const form = new FormData(e.currentTarget);
    setBusy(true); setNotice("");
    const files = form.getAll("photos").filter((f): f is File => f instanceof File && f.size > 0);
    const urls: string[] = [];
    for (const file of files.slice(0, 5)) {
      const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
      const path = `${session.user.id}/${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from("listing-photos").upload(path, file, { upsert: false, contentType: file.type });
      if (error) { setNotice("Foto upload mislukt: " + error.message); setBusy(false); return; }
      const { data } = supabase.storage.from("listing-photos").getPublicUrl(path);
      urls.push(data.publicUrl);
    }
    const { error } = await supabase.from("listings").insert({
      user_id: session.user.id, title: form.get("title"), description: form.get("description"),
      category: form.get("category"), amount_eur: Number(form.get("amount_eur")),
      city: form.get("city"), postal_code: form.get("postal_code") || null,
      condition: form.get("condition"), image_urls: urls
    });
    setBusy(false);
    if (error) setNotice(error.message);
    else { setNotice("Advertentie succesvol geplaatst."); (e.target as HTMLFormElement).reset(); setTab("home"); loadListings(); }
  }
  async function startConversation(listing: Listing) {
    if (!session) { setAuthOpen(true); return; }
    if (listing.user_id === session.user.id) { setNotice("Dit is je eigen advertentie."); return; }
    const { data, error } = await supabase.from("conversations").upsert(
      { listing_id: listing.id, buyer_id: session.user.id, owner_id: listing.user_id },
      { onConflict: "listing_id,buyer_id" }).select("*, listings(*)").single();
    if (error) setNotice(error.message);
    else { setActiveConversation(data as Conversation); setTab("messages"); loadConversations(); setDetail(null); }
  }
  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!activeConversation || !messageText.trim()) return;
    const body = messageText.trim(); setMessageText("");
    const { error } = await supabase.from("messages").insert({ conversation_id: activeConversation.id, sender_id: session.user.id, body });
    if (error) setNotice(error.message);
  }
  async function signOut() { await supabase.auth.signOut(); setTab("home"); setActiveConversation(null); }
  async function updateStatus(id: string, status: string) {
    const { error } = await supabase.from("listings").update({ status }).eq("id", id);
    if (error) setNotice(error.message); else { loadListings(); setNotice("Advertentie bijgewerkt."); }
  }

  const visibleListings = useMemo(() => listings, [listings]);
  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={() => {setTab("home");setDetail(null)}}><span className="brand-mark"><Recycle size={23}/></span><span>Sad<span>Red</span><small>Geef spullen een tweede leven</small></span></button>
      <nav className="desktop-nav">
        <button className={tab==="home"?"active":""} onClick={()=>{setTab("home");setDetail(null)}}>Ontdekken</button>
        <button className={tab==="publish"?"active":""} onClick={()=>setTab("publish")}><Plus size={16}/> Plaatsen</button>
        <button className={tab==="messages"?"active":""} onClick={()=>setTab("messages")}><MessageCircle size={16}/> Berichten</button>
      </nav>
      <div className="top-actions">
        {profile?.role === "admin" && <button className="icon-button" title="Beheer" onClick={()=>setTab("admin")}><ShieldCheck/></button>}
        {session ? <button className="account-button" onClick={()=>setTab("account")}><UserRound size={17}/><span>{profile?.display_name || "Mijn account"}</span></button>
          : <button className="button button-dark" onClick={()=>setAuthOpen(true)}>Inloggen</button>}
      </div>
    </header>

    {!isConfigured && <div className="setup-banner"><strong>Configuratie nodig:</strong> voeg je Supabase URL en anon key toe in <code>.env</code> en voer <code>supabase/schema.sql</code> uit. Daarna werken accounts, advertenties, foto's en chat.</div>}
    {notice && <div className="notice" role="status">{notice}<button onClick={()=>setNotice("")}><X size={16}/></button></div>}

    {detail ? <main className="content detail-page">
      <button className="back-link" onClick={()=>setDetail(null)}>← Terug naar advertenties</button>
      <div className="detail-grid">
        <div className="detail-photo">{detail.image_urls?.[0] ? <img src={detail.image_urls[0]} alt={detail.title}/> : <div className="photo-placeholder"><PackageOpen size={60}/></div>}</div>
        <section className="detail-info"><span className="eyebrow">{detail.category} · {detail.condition}</span><h1>{detail.title}</h1><div className="big-price">{money(detail.amount_eur)}</div><p className="pays-label">Bedrag dat de plaatser betaalt aan de ophaler</p><p>{detail.description}</p><p className="location"><MapPin size={17}/>{detail.city} {detail.postal_code}</p><p className="muted">Geplaatst door {detail.profiles?.display_name || "SadRed-gebruiker"}</p>
          <button className="button button-green full" onClick={()=>startConversation(detail)}><MessageCircle size={18}/> Ik kan dit ophalen</button>
          {session?.user?.id === detail.user_id && <button className="button button-outline full" onClick={()=>updateStatus(detail.id,"completed")}>Markeer als opgehaald</button>}
        </section>
      </div>
    </main> : tab==="home" ? <main>
      <section className="hero"><div className="hero-copy"><span className="eyebrow light">SLIM OPHALEN · SAMEN HERGEBRUIKEN</span><h1>Jij wilt ervan af.<br/><em>Iemand anders</em> haalt het op.</h1><p>Plaats wat je kwijt wilt en bepaal zelf hoeveel je betaalt. Vind iemand in je buurt die het komt ophalen.</p><button className="button button-lime" onClick={()=>setTab("publish")}><Plus size={18}/> Plaats gratis een advertentie</button></div><div className="hero-art"><div className="hero-circle"><Recycle size={112}/></div><div className="floating-card"><span>Jij bepaalt</span><strong>€ 25</strong><small>ophaalkosten</small></div></div></section>
      <section className="content listings-section"><div className="section-heading"><div><span className="eyebrow">ONTDEK IN JOUW BUURT</span><h2>Wat wordt er aangeboden?</h2></div><span className="count">{visibleListings.length} advertenties</span></div>
        <div className="search-row"><div className="searchbox"><Search size={19}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Zoek meubels, toestellen, tuin..." /></div><div className="category-pills">{categories.map(c=><button key={c} className={category===c?"selected":""} onClick={()=>setCategory(c)}>{c}</button>)}</div></div>
        {visibleListings.length ? <div className="listing-grid">{visibleListings.map(item=><article className="listing-card" key={item.id} onClick={()=>setDetail(item)}><div className="listing-image">{item.image_urls?.[0]?<img src={item.image_urls[0]} alt={item.title}/>:<div className="photo-placeholder"><PackageOpen size={42}/></div>}<span className="category-tag">{item.category}</span></div><div className="listing-body"><h3>{item.title}</h3><p className="location"><MapPin size={14}/>{item.city}</p><div className="card-bottom"><div><strong>{money(item.amount_eur)}</strong><small>betaald aan ophaler</small></div><span className="arrow-circle">↗</span></div></div></article>)}</div>
          : <div className="empty-state"><PackageOpen size={42}/><h3>Nog geen advertenties gevonden</h3><p>Wees de eerste en plaats iets dat opgehaald mag worden.</p><button className="button button-green" onClick={()=>setTab("publish")}>Advertentie plaatsen</button></div>}
      </section>
    </main> : tab==="publish" ? <main className="content form-page"><div className="form-intro"><span className="eyebrow">VERKOOP NIET, LAAT OPHALEN</span><h1>Wat wil je laten ophalen?</h1><p>Voeg foto's en details toe. Jij bepaalt het bedrag dat je wilt betalen.</p></div><form className="panel listing-form" onSubmit={publish}>
      <label className="field"><span>Titel *</span><input name="title" required maxLength={90} placeholder="Bijv. Oude zetel gratis mee te nemen?"/></label>
      <label className="field"><span>Beschrijving *</span><textarea name="description" required rows={4} maxLength={1500} placeholder="Beschrijf het voorwerp, de staat en hoe het opgehaald kan worden."/></label>
      <div className="form-two"><label className="field"><span>Categorie *</span><select name="category" required>{categories.filter(x=>x!=="Alles").map(c=><option key={c}>{c}</option>)}</select></label><label className="field"><span>Staat *</span><select name="condition"><option>Gebruikt</option><option>Nieuw</option><option>Defect</option><option>Voor onderdelen</option></select></label></div>
      <div className="form-two"><label className="field"><span>Bedrag voor de ophaler (€) *</span><input name="amount_eur" type="number" min="0" max="5000" step="0.50" required placeholder="25"/></label><label className="field"><span>Gemeente *</span><input name="city" required placeholder="Antwerpen"/></label></div>
      <label className="field"><span>Postcode (optioneel)</span><input name="postal_code" maxLength={10} placeholder="2000"/></label>
      <label className="field"><span>Foto's (max. 5)</span><div className="upload-box"><Camera/><span>Voeg foto's toe</span><small>JPG, PNG of WebP · max. 8 MB per foto</small><input name="photos" type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={e=>{if(e.target.files && [...e.target.files].some(f=>f.size>8*1024*1024)) {setNotice("Elke foto mag maximaal 8 MB zijn.");e.target.value="";} if((e.target.files?.length||0)>5){setNotice("Je kunt maximaal 5 foto's kiezen.");e.target.value="";}}}/></div></label>
      <p className="form-note">Door te plaatsen bevestig je dat je gerechtigd bent het voorwerp mee te geven en dat de informatie klopt.</p>
      <button className="button button-green full" disabled={busy}>{busy?"Bezig met plaatsen...":"Advertentie publiceren"}</button>
    </form></main> : tab==="messages" ? <main className="content messages-page"><div className="form-intro"><span className="eyebrow">CONTACT</span><h1>Berichten</h1><p>Maak afspraken over het ophalen rechtstreeks met elkaar.</p></div><div className="chat-layout panel"><aside className="conversation-list"><h3>Gesprekken</h3>{myConversations.map(c=><button key={c.id} className={activeConversation?.id===c.id?"conversation active":"conversation"} onClick={()=>setActiveConversation(c)}><strong>{c.listings?.title||"Advertentie"}</strong><small>{c.buyer_id===session?.user?.id?"Jij bent de ophaler":"Jij bent de plaatser"}</small></button>)}{!myConversations.length&&<p className="muted pad">Je gesprekken verschijnen hier.</p>}</aside><section className="chat-window">{activeConversation?<><div className="chat-title"><strong>{activeConversation.listings?.title||"Gesprek"}</strong><small>{activeConversation.listings?money(activeConversation.listings.amount_eur):""}</small></div><div className="chat-messages">{messages.map(m=><div key={m.id} className={m.sender_id===session?.user?.id?"bubble mine":"bubble"}>{m.body}<small>{new Date(m.created_at).toLocaleString("nl-BE")}</small></div>)}</div><form className="chat-compose" onSubmit={sendMessage}><input value={messageText} onChange={e=>setMessageText(e.target.value)} placeholder="Typ een bericht..." required/><button className="button button-green" aria-label="Versturen"><Send size={17}/></button></form></>:<div className="empty-state"><MessageCircle size={42}/><h3>Kies een gesprek</h3><p>Open een advertentie en klik op ‘Ik kan dit ophalen’ om contact te leggen.</p></div>}</section></div></main> : tab==="account" ? <main className="content form-page"><div className="form-intro"><span className="eyebrow">PERSOONLIJK</span><h1>Mijn account</h1></div><div className="panel account-panel"><div className="avatar"><UserRound/></div><h2>{profile?.display_name||"SadRed-gebruiker"}</h2><p className="muted">{session?.user?.email}</p><button className="button button-outline full" onClick={signOut}><LogOut size={17}/> Uitloggen</button></div></main> : <main className="content form-page"><div className="form-intro"><span className="eyebrow">BEHEER</span><h1>Admin dashboard</h1><p>Overzicht van advertenties op SadRed.</p></div><div className="panel admin-panel"><div className="stat"><strong>{listings.length}</strong><span>Actieve advertenties geladen</span></div><h3>Advertenties beheren</h3>{listings.map(l=><div className="admin-row" key={l.id}><span><b>{l.title}</b><small>{l.city} · {money(l.amount_eur)}</small></span><button className="button button-outline" onClick={()=>updateStatus(l.id,"removed")}>Verwijderen</button></div>)}</div></main>}

    <footer className="footer"><div className="footer-brand"><Recycle/> <strong>SadRed</strong></div><span>Geef spullen een tweede leven.</span><small>© {new Date().getFullYear()} SadRed · België</small></footer>
    <nav className="mobile-nav"><button onClick={()=>{setTab("home");setDetail(null)}} className={tab==="home"?"active":""}><Search/><span>Ontdekken</span></button><button onClick={()=>setTab("publish")} className={tab==="publish"?"active":""}><Plus/><span>Plaatsen</span></button><button onClick={()=>setTab("messages")} className={tab==="messages"?"active":""}><MessageCircle/><span>Berichten</span></button><button onClick={()=>session?setTab("account"):setAuthOpen(true)}><UserRound/><span>Account</span></button></nav>

    {authOpen && <div className="modal-backdrop" onClick={()=>setAuthOpen(false)}><form className="auth-modal panel" onSubmit={signIn} onClick={e=>e.stopPropagation()}><button type="button" className="modal-close" onClick={()=>setAuthOpen(false)}><X/></button><span className="eyebrow">WELKOM BIJ SADRED</span><h2>{authMode==="signup"?"Account aanmaken":"Inloggen"}</h2><p className="muted">Maak contact met mensen in je buurt.</p>{authMode==="signup"&&<label className="field"><span>Naam</span><input value={displayName} onChange={e=>setDisplayName(e.target.value)} required placeholder="Je naam"/></label>}<label className="field"><span>E-mailadres</span><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="naam@email.be"/></label><label className="field"><span>Wachtwoord</span><input type="password" minLength={8} value={password} onChange={e=>setPassword(e.target.value)} required placeholder="Minimaal 8 tekens"/></label><button className="button button-green full" disabled={busy}>{busy?"Even wachten...":authMode==="signup"?"Account aanmaken":"Inloggen"}</button><button type="button" className="text-button" onClick={()=>setAuthMode(authMode==="signup"?"login":"signup")}>{authMode==="signup"?"Heb je al een account? Inloggen":"Nog geen account? Registreren"}</button></form></div>}
  </div>;
}