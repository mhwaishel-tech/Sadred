-- SadRed MVP database setup. Run once in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 3 and 90),
  description text not null check (char_length(description) between 5 and 1500),
  category text not null check (category in ('Meubels','Huishoudtoestellen','Tuin','Bouwafval','Overig')),
  amount_eur numeric(8,2) not null check (amount_eur >= 0 and amount_eur <= 5000),
  city text not null,
  postal_code text,
  condition text not null default 'Gebruikt',
  image_urls text[] not null default '{}',
  status text not null default 'active' check (status in ('active','reserved','completed','removed')),
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  buyer_id uuid not null references public.profiles(id) on delete cascade,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (listing_id, buyer_id),
  check (buyer_id <> owner_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 3000),
  created_at timestamptz not null default now()
);

create index if not exists listings_active_created_idx on public.listings(status, created_at desc);
create index if not exists listings_city_idx on public.listings(city);
create index if not exists conversations_buyer_idx on public.conversations(buyer_id);
create index if not exists conversations_owner_idx on public.conversations(owner_id);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at);

-- Automatically create a profile after email sign-up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)));
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Admin helper; only a trusted admin can change role using SQL dashboard.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'); $$;

alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;

create policy "Profiles are visible to authenticated users" on public.profiles
for select to authenticated using (true);
create policy "Users update own profile" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and role = (select role from public.profiles p where p.id = auth.uid()));

create policy "Active listings are public; owners and admins see all" on public.listings
for select using (status = 'active' or user_id = auth.uid() or public.is_admin());
create policy "Authenticated users create own listings" on public.listings
for insert to authenticated with check (user_id = auth.uid());
create policy "Owners or admins update listings" on public.listings
for update to authenticated using (user_id = auth.uid() or public.is_admin())
with check (user_id = auth.uid() or public.is_admin());
create policy "Owners or admins delete listings" on public.listings
for delete to authenticated using (user_id = auth.uid() or public.is_admin());

create policy "Conversation participants read conversations" on public.conversations
for select to authenticated using (buyer_id = auth.uid() or owner_id = auth.uid() or public.is_admin());
create policy "Buyer starts conversation for another user's listing" on public.conversations
for insert to authenticated with check (
  buyer_id = auth.uid() and owner_id <> auth.uid()
  and exists (select 1 from public.listings l where l.id = listing_id and l.user_id = owner_id and l.status = 'active')
);
create policy "Participants read messages" on public.messages
for select to authenticated using (
  exists (select 1 from public.conversations c where c.id = conversation_id and (c.buyer_id = auth.uid() or c.owner_id = auth.uid()))
  or public.is_admin()
);
create policy "Participants send own messages" on public.messages
for insert to authenticated with check (
  sender_id = auth.uid() and exists (
    select 1 from public.conversations c where c.id = conversation_id and (c.buyer_id = auth.uid() or c.owner_id = auth.uid())
  )
);

-- Public read access for listing images; only signed-in users can upload into their own folder.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('listing-photos', 'listing-photos', true, 8388608, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 8388608, allowed_mime_types = array['image/jpeg','image/png','image/webp'];

create policy "Public can view listing photos" on storage.objects
for select using (bucket_id = 'listing-photos');
create policy "Users upload photos into own folder" on storage.objects
for insert to authenticated with check (bucket_id = 'listing-photos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Users delete own photos" on storage.objects
for delete to authenticated using (bucket_id = 'listing-photos' and (storage.foldername(name))[1] = auth.uid()::text);

-- Enable realtime for messages (ignore if already added).
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
end $$;

-- After creating your account, promote your own user to admin manually:
-- update public.profiles set role = 'admin' where id = 'YOUR-AUTH-USER-UUID';
